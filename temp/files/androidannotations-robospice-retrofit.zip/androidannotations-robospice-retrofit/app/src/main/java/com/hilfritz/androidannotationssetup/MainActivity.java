package com.hilfritz.androidannotationssetup;


import android.os.Bundle;
import android.widget.TextView;

import com.hilfritz.webserviceclient.requests.SearchArtistRequest;
import com.hilfritz.webserviceclient.wrapper.SearchWrapper;
import com.octo.android.robospice.persistence.DurationInMillis;
import com.octo.android.robospice.persistence.exception.SpiceException;
import com.octo.android.robospice.request.listener.RequestListener;

import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

@EActivity(R.layout.activity_main)
public class MainActivity extends BaseActivity {
    @ViewById
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
    }

    @Click
    void myButton() {
        //Toast.makeText(this,"Hello World", Toast.LENGTH_SHORT).show();
        searchEminem();
    }

    public void searchEminem(){
        //PERFORM SEARCH
        SearchArtistRequest searchArtistRequest = new SearchArtistRequest("eminem", SearchArtistRequest.DEFAULT_LIMIT * 10, SearchArtistRequest.DEFAULT_OFFSET);
        ((BaseActivity)this).getSpiceManager().execute(searchArtistRequest, "search", DurationInMillis.ALWAYS_EXPIRED, new SearchRequestListener());
    }

    private class SearchRequestListener implements RequestListener<SearchWrapper> {

        @Override
        public void onRequestFailure(SpiceException spiceException) {
            textView.setText("exception");
        }


        @Override
        public void onRequestSuccess(SearchWrapper searchWrapper) {
            textView.setText(textView.getText() + " \n" + searchWrapper.getArtists().getItems().size() + " request result size.");
        }
    }
}
