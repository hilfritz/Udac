package com.hilfritz.androidannotationssetup;

import android.app.Activity;

import com.hilfritz.webserviceclient.SpotifySpiceService;
import com.octo.android.robospice.SpiceManager;

/**
 * Created by Hilfritz P. Camallere on 11/16/2015.
 */
public abstract class BaseActivity extends Activity{
    //this is the spice manager, we pass our service class that handles
    //all rest requests
    private SpiceManager spiceManager = new SpiceManager(SpotifySpiceService.class);

    @Override
    protected void onStart() {
        super.onStart();
        spiceManager.start(getApplicationContext());

    }
    @Override
    protected void onStop() {
        super.onStop();
        spiceManager.shouldStop();
    }
    public SpiceManager getSpiceManager() {
        return spiceManager;
    }
}